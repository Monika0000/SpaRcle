Code for http://mycodelog.com/2010/04/01/xml-editor/

<img title="Xml Editor" src="http://alibad.files.wordpress.com/2010/04/xml-editor.jpg" alt="" width="632" height="672" />