Visual Studio 2015 Project for a sample OpenGL app that displays the screen resolution (m x n grid of pixels) and the screen dimension in millimeters

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [GLUT Screen Resolution](http://mycodelog.com/2010/05/16/glresolution/)
