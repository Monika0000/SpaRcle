C++ source code that shows how to create your first GLUI window with some basic controls inside it, and provides you with a template for your OpenGL applications.

More details: 

* [GLUI Window Template - Summary](http://mycodelog.com/2008/01/25/glui-window-template/)
* [GLUI Window Template - Details](http://www.codeproject.com/Articles/20286/GLUI-Window-Template)
