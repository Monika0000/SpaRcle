Visual Studio 2015 Project for a sample OpenGL Free GLUT window, which you can use as a template for your OpenGL applications.

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [GLUT Window Template - Summary](http://mycodelog.com/2008/01/20/glut-window-template/)
* [GLUT Window Template - Details](http://www.codeproject.com/Articles/19760/GLUT-Window-Template)
