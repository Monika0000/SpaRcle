Visual Studio 2015 Project for an OpengGL app that shows the frame rate for the animation being shown.

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [OpenGL Frame Rate](http://mycodelog.com/2010/04/16/fps/)
