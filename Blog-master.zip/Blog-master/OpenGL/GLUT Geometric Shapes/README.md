Visual Studio 2015 Project to explore GLUT shapes, rorate\resize them, switch between solid and wireframe, and change their color.

<img title="GLUT Shapes" src="http://alibad.files.wordpress.com/2010/03/glut-shapes1.jpg" alt="GLUT Shapes" width="530" height="555" />

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [GLUT Geometric Shapes](http://mycodelog.com/2010/03/28/glut-shapes/)
