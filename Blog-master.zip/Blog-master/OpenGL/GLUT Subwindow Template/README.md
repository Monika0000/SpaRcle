Visual Studio 2015 Project for a sample OpenGL Free GLUT window with multiple subwindows, which you can use as a template for your OpenGL applications.

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [GLUT Subwindow Template - Summary](http://mycodelog.com/2008/01/22/glut-subwindow-template/)
* [GLUT Subwindow Template - Details](http://www.codeproject.com/Articles/20107/GLUT-Subwindow-Template)
