#ifndef GLTEXT_H
#define GLTEXT_H

//  printf prints to file. printw prints to window
void printw (float x, float y, float z, char* format, ...);

#endif