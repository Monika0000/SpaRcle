Visual Studio 2015 Project for an image generator OpenGL app that demonstrate the usage of the glDrawPixels function to draw pixels in the frame buffer. 

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [Image Generator](http://mycodelog.com/2010/05/15/glpix/)
