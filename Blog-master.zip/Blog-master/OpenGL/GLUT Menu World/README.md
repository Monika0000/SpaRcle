Visual Studio 2015 Project for a simple OpenGL app that shows you how to create right-click menu items in GLUT.

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [GLUT Menu Items](http://mycodelog.com/2010/05/27/glut-menu/)
