Visual Studio 2015 Project for a sample OpenGL app that shows you how to draw a circle, oval or arc and explains the math behind it.

<img title="circle" src="http://alibad.files.wordpress.com/2010/03/circle.jpg" alt="OpenGL Oval" width="632" height="131" />

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [OpenGL Oval](http://mycodelog.com/2010/03/22/opengl-oval/)
