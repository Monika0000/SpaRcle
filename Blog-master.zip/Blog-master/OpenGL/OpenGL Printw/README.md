Visual Studio 2015 Project for printw function that significantly simplifies printing characters on an OpenGL screen.

<img title="printw" src="http://alibad.files.wordpress.com/2010/03/printw.jpg" alt="OpenGL printw" width="418" height="143" />

More details: 

* [OpenGL Free GLUT in Visual C++ 2015](http://mycodelog.com/2015/10/08/opengl-freeglut-in-visual-studio-2015/)
* [OpenGL printw](http://mycodelog.com/2010/03/23/printw/)
