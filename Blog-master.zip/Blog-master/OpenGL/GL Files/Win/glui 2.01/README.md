Windows files for the GLUI library 2.01.

http://glui.sourceforge.net/

Disclaimer: I have not created or modified any of those files, nor do I claim any ownership of them. They were simply collected from different sources and redistributed.