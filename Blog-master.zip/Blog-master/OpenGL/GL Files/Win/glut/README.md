Windows files for the GLUT library.

https://www.opengl.org/resources/libraries/glut/

Disclaimer: I have not created or modified any of those files, nor do I claim any ownership of them. They were simply collected from different sources and redistributed.