Windows files for the FreeGLUT library.

http://freeglut.sourceforge.net/

Disclaimer: I have not created or modified any of those files, nor do I claim any ownership of them. They were simply collected from different sources and redistributed.