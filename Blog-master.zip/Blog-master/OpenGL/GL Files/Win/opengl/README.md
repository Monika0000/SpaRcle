Windows files for the OpenGL library.

https://www.opengl.org
GLU: https://www.opengl.org/archives/resources/faq/technical/glu.htm

Disclaimer: I have not created or modified any of those files, nor do I claim any ownership of them. They were simply collected from different sources and redistributed.