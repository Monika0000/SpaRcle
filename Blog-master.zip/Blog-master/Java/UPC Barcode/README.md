Code for http://mycodelog.com/2008/06/04/java-upc-a-barcode-generator/

<img  src="https://alibad.files.wordpress.com/2008/06/barcodegenerator.jpg?w=300" alt="UPC-A Barcode Generator" width="300" height="244" />