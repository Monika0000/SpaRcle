Code for http://mycodelog.com/2010/02/11/busy/

<img title="BusyForm" src="http://alibad.files.wordpress.com/2010/02/busyform2.jpg" alt="" width="252" height="502" />