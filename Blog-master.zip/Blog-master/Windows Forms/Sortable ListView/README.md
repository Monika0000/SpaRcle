Code for http://mycodelog.com/2010/01/16/sortablelistview/

<img title="SortableListView" src="http://alibad.files.wordpress.com/2010/01/sortablelistview.jpg" alt="Sortable ListView" width="403" height="208" />