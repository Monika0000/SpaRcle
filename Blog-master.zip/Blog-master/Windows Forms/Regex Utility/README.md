Code for http://mycodelog.com/2009/12/22/regexui/

<img src="http://alibad.wordpress.com/files/2009/12/regexhelp.jpg" alt="C# Regular Expression Helper" />