Code for http://mycodelog.com/2010/03/03/spsites/

