Code for http://mycodelog.com/2010/03/18/spicon/

<img title="spicon" src="http://alibad.files.wordpress.com/2010/03/spicon.jpg" alt="" width="295" height="249" />